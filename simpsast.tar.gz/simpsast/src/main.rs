use std::io::{BufRead, BufReader, Write, BufWriter};
use std::fs::File;
use std::env;
use std::collections::HashSet;

use regex::Regex;
use lazy_static::*;
use ansi_term::Color;

lazy_static! {
    static ref P_IPV6: Regex = Regex::new(r"((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:)))(%.+)?").expect("bad regex.");

    static ref P_IPV4: Regex = Regex::new(r"(?:(?:[0-1]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])[.](?:[0-1]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])[.](?:[0-1]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])[.](?:[0-1]?[0-9]{1,2}|2[0-4][0-9]|25[0-5]))").expect("bad regex.");

    static ref P_URI: Regex = Regex::new(r"(http[s]?)://([^@^\s]:[^@^\s])?([^/^\s]{1,63}\.){1,4}([A-Za-z]{2,25})").expect("Bad regex.");

    static ref P_HASHES: Regex = Regex::new(r"(^[0-9A-Fa-f]{128,160})").expect("Bad Regex.");
}


/// Problems:
/// - only checks utf8 text
/// - lots of false positives on IPV4 addresses
/// - needs summary stats
/// - P_URI only checks http & https
/// - needs to look for other sources of unintended network access
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = env::args().collect();

    let mut matches: HashSet<String> = HashSet::new();
    let mut hashes: HashSet<String> = HashSet::new();

    if let Ok(f) = File::open(&args[1]) {
        let reader = BufReader::new(f);
        let lines = reader.lines().map(|line| { line.unwrap_or_default() });

        println!("---- Grepping file: {} ----\n\n", Color::Yellow.paint(&args[1]));
        for (i, subject) in lines.enumerate() {
            matches.insert(find_ip4(&i, &subject).unwrap_or_default());
            matches.insert(find_ip6(&i, &subject).unwrap_or_default());
            matches.insert(find_uris(&i, &subject).unwrap_or_default());
            hashes.insert(find_hashes(&i, &subject).unwrap_or_default());
        }
    } else {
        println!("---- Could not open file: {} ----", &args[1]);
    }

    let out = File::options().read(true).write(true).open("hits.txt")?;
    {
        let mut writer = BufWriter::new(out);
        for mut m in matches {
            m.push('\n');
            writer.write_all(m.as_bytes())?;
        }
    }

    let potential_hashes = File::options().read(true).write(true).open("hashes.txt")?;
    {
        let mut writer = BufWriter::new(potential_hashes);
        for mut m in hashes {
            m.push('\n');
            writer.write_all(m.as_bytes())?;
        }
    }

    Ok(())
}

fn find_ip4(line: &usize, subject: &str) -> Option<String> {
    let caps: Vec<_> = P_IPV4.captures_iter(&subject).collect();
    if caps.len() > 0 {
        let line = format!("{}", line + 1);
        println!("\tIPV4: {}\n \tTXT: {}", Color::Yellow.paint(line), &subject);
        for cap in caps {
            match cap.get(0) {
                Some(m) => {
                    println!("\t\tMATCH: {}", Color::Red.paint(m.as_str()));
                    return Some(String::from(m.as_str()));
                }
                _ => {}
            }
        }
        print!("\n");
    }
    None
}

fn find_ip6(line: &usize, subject: &str) -> Option<String> {
    let caps: Vec<_> = P_IPV6.captures_iter(&subject).collect();
    if caps.len() > 0 {
        let line = format!("{}", line + 1);
        let mut finds = String::new();
        let mut display = String::new();
        for cap in caps {
            match cap.get(0) {
                Some(m) if m.as_str().len() > 9 => {
                    let mat = format!("\t\tMATCH: {}\n", Color::Red.paint(m.as_str()));
                    display.push_str(&mat);
                    finds.push_str(m.as_str());
                    finds.push('\n');
                }
                _ => {}
            }
        }

        if finds.len() > 0 {
            print!("\tIPV6: {}\n \tTXT: {}\n", Color::Yellow.paint(line), &subject);
            print!("{}", &display);
            print!("\n");
            return Some(finds);
        }
    }

    None
}

fn find_uris(line: &usize, subject: &str) -> Option<String> {
    let caps: Vec<_> = P_URI.captures_iter(&subject).collect();
    if caps.len() > 0 {
        let line = format!("{}", line + 1);
        println!("\tURI: {}\n \tTXT: {}", Color::Yellow.paint(line), &subject);
        for cap in caps {
            match cap.get(0) {
                Some(m) => {
                    println!("\t\tMATCH: {}", Color::Green.paint(m.as_str()));
                    return Some(String::from(m.as_str()));
                }
                _ => {}
            }
        }
        print!("\n");
    }

    None
}

fn find_hashes(line: &usize, subject: &str) -> Option<String> {
    let caps: Vec<_> = P_HASHES.captures_iter(&subject).collect();
    if caps.len() > 0 {
        for cap in caps {
            match cap.get(0) {
                Some(m) => {
                    return Some(String::from(m.as_str()));
                }
                _ => {}
            }
        }
    }
    None
}